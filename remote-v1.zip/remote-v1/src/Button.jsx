import React from 'react'

export default function Button() {
  return (
    <button style={{ padding: 12, borderRadius: 4, background: 'skyblue' }}>
      Versión 1
    </button>
  );
}
